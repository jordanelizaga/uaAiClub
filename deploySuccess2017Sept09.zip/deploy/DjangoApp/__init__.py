"""
Package for DjangoApp.
"""
